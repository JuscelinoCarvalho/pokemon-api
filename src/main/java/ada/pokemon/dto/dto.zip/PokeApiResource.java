package ada.pokemon.dto;

public interface PokeApiResource {

	Integer getId();
	String getName();
	
}
