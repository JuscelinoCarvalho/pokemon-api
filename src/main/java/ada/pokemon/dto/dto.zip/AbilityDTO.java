package ada.pokemon.dto;


import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class AbilityDTO {
    private String name;
    private String effect;

    public AbilityDTO(){}
}
