package ada.pokemon.dto;


public interface PokemonInterface {

    PokemonDTO getPokemon(String pokemonName);
}

