package ada.pokemon.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Getter
@Setter
public class PokemonDTO {

    @JsonProperty("abilities")
    private List<String> abilities;

    @JsonProperty("base_experience")
    private Integer base_experience;

    @JsonProperty("forms")
    private List<String> forms;

    @JsonProperty("game_indices")
    private List<String> game_indices;

    @JsonProperty("height")
    private Integer height;

    @JsonProperty("held_items")
    private List<String> held_items;

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("is_default")
    private boolean is_default;

    @JsonProperty("location_area_encounters")
    private String location_area_encounters;

    @JsonProperty("moves")
    private List<String> moves;

    @JsonProperty("name")
    private String name;

    @JsonProperty("order")
    private Integer order;

    @JsonProperty("past_types")
    private List<String> past_types;

    @JsonProperty("species")
    private String species;

    @JsonProperty("sprites")
    private String sprites;

    @JsonProperty("stats")
    private List<String> stats;

    @JsonProperty("types")
    private List<String> types;

    @JsonProperty("weight")
    private Integer weight;

    public PokemonDTO(){}
}
