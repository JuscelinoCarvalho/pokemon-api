package ada.pokemon.dto;

import java.util.List;

import skaro.pokeapi.resource.Name;

public interface Localizable {

	List<Name> getNames();
	
}
